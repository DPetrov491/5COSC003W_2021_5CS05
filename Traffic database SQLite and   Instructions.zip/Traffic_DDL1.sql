/*
**	5COSC003W.2 Software Development Group Project
*	Coursework 2
*	
*	Omar Ahmed
*	
*	Traffic Database objects DDL script
*
*	22/03/2021
*
*/

-- SQLite Group 5CS05 v0.1


/*
Drop existing tables
*/
DROP TABLE Count_Point;
DROP TABLE Juction;
DROP TABLE Roads;
DROP TABLE Local_Authority;
DROP TABLE Region;

/*
Create Region table
*/
CREATE TABLE Region
(
region_id	INT(3) 		NOT NULL,
region_name VARCHAR2(30) NOT NULL,
CONSTRAINT c_rid_pk PRIMARY KEY (region_id)
);

/*
Create Local_Authority table
*/
CREATE TABLE Local_Authority
(
local_authority_id	 INT(3) NOT NULL,
local_authority_name VARCHAR2(30) NOT NULL,
CONSTRAINT c_laid_pk PRIMARY KEY (local_authority_id)
);

/*
Create Roads table
*/
CREATE TABLE Roads
(
road_name	VARCHAR2(50) NOT NULL,
road_type	VARCHAR2(15) NOT NULL,
CONSTRAINT c_rn_pk PRIMARY KEY (road_name)
);	

/*
Create Juction table
*/	
CREATE TABLE Juction
(	
road_name					VARCHAR2(50),	
start_junction_road_name	VARCHAR2(80),
end_junction_road_name		VARCHAR2(80),
easting	northing			INT(6),
latitude					DECIMAL(3,8),
longitude					DECIMAL(3,8),
link_length_km				DECIMAL(8,2),
link_length_miles			DECIMAL(8,2)
);

/*
Create Count_Point table
*/
CREATE TABLE Count_Point
(	
count_point_id					INT(8) NOT NULL,
direction_of_travel				VARCHAR2(1),
year							INT(4),
count_date						DATE,
hour							NUMBER,
region_id						INT(3),
local_authority_id				INT(3),
road_name						VARCHAR2(50),	
start_junction_road_name		VARCHAR2(50),
end_junction_road_name			VARCHAR2(50),
pedal_cycles					VARCHAR2(50),
two_wheeled_motor_vehicles		VARCHAR2(50),
cars_and_taxis					INT(6),
buses_and_coaches				INT(6),
lgvs							INT(6),
hgvs_2_rigid_axle				INT(6),
hgvs_3_rigid_axle				INT(6),
hgvs_4_or_more_rigid_axle		INT(6),
hgvs_3_or_4_articulated_axle	INT(6),
hgvs_5_articulated_axle			INT(6),
hgvs_6_articulated_axle			INT(6)
);


DROP VIEW dft_rawcount_local_authority_id_42;

CREATE VIEW dft_rawcount_local_authority_id_42 AS
SELECT 1 from region;

SELECT * FROM dft_rawcount_local_authority_id_42;