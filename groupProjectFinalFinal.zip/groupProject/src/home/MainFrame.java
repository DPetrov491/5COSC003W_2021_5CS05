/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package home;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable.*;
import javax.swing.table.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jdbcApi.connectDB;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.jdbc.JDBCCategoryDataset;
import org.jfree.data.jdbc.JDBCPieDataset;

/**
 *
 * @authors Dimitar, Omar, Calixto;
 */
public class MainFrame extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public MainFrame() {
        initComponents();
    }

    String pUserId;
    String pLogInDateTime;
    String userType;
    String userName;
    Integer tc_id;
    Integer row;
    
    //get user id from login.java
    public void getUserId(String userId) {
        this.pUserId = userId;
    }
    
    //get date and time of login from login.java
    public void getLogInDateTime(String logInDateTime) {
        this.pLogInDateTime = logInDateTime;
    }
    
    //check if the user has admin rights
    public void isUserAdmin() {
        try {
            String sqlQuery = ("SELECT userType, username FROM Users WHERE userId = ?");
            Connection con = connectDB.getConnection();
            PreparedStatement pst = con.prepareStatement(sqlQuery);

            pst.setString(1, pUserId);

            ResultSet rs = pst.executeQuery();
            userType = rs.getString(1);
            userName = rs.getString(2);
            System.out.println(userName);
            pst.close();
            con.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }

        if (userType.equals("C")) {
            adminPanelLabel.setVisible(false);
            welcomeLabel.setText("Hello, " + userName + " you are logged in as Customer");
        } else if (userType.equals("A")) {
            adminPanelLabel.setVisible(true);
            welcomeLabel.setText("Hello, " + userName + " you are logged in as Administrator!");
        }

    }
    //On close log out user and record logInDateTime, logOutDateTime and userId to users_activity
    public void logOutUser() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String logOutDateTime = sdf.format(timestamp);

        try {
            String sqlQuery = ("INSERT INTO Users_Activity (logInDateTime, logOutDateTime, userId) " + "VALUES (?,?,?)");

            Connection con = connectDB.getConnection();
            PreparedStatement pst = con.prepareStatement(sqlQuery);

            pst.setString(1, pLogInDateTime);
            pst.setString(2, logOutDateTime);
            pst.setString(3, pUserId);
            pst.executeUpdate();

            pst.close();
            con.close();

            JOptionPane.showMessageDialog(null, "You have logged out! You will reutrn to the Log In Page.");

            if (JOptionPane.OK_OPTION == 0) {

                this.setVisible(false);
                new Login().setVisible(true);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
    
    //admin button function
    public void toggleAdminPanel() {

        dashboard1Panel.setVisible(false);
        dashboard2Panel.setVisible(false);
        adminPanel.setVisible(true);

    }
    
    //dash1 button function
    public void toggleDash1() {

        dashboard1Panel.setVisible(true);
        dashboard2Panel.setVisible(false);
        adminPanel.setVisible(false);

    }
    
    //dash2 button function
    public void toggleDash2() {

        dashboard1Panel.setVisible(false);
        dashboard2Panel.setVisible(true);
        adminPanel.setVisible(false);

    }
    
    
    // show admin panel 
    public void showAdminPanel() {
        Connection con = connectDB.getConnection();
        try {
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("Select userId, userName, email, userType, regDateTime from Users");
            // for changing column and row model
            DefaultTableModel tm = (DefaultTableModel) adminPanelTable.getModel();

            // clear existing rows
            tm.setRowCount(0);

            // add rows to table
            while (rs.next()) {
                String[] a = new String[5];
                for (int i = 0; i < 5; i++) {
                    a[i] = rs.getString(i + 1);
                }
                tm.addRow(a);
            }
            tm.fireTableDataChanged();

            stmt.close();
            rs.close();
            con.close();

        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }
    }
    
    //delete row function.
    public void deleteRow() {
        DefaultTableModel tm = (DefaultTableModel) adminPanelTable.getModel();

        tm.removeRow(row);
        tm.fireTableDataChanged();

    }


    String RoadName = "M80", Year = "2000";

    public void PopulateComboBox1() {
        // Populate ComboBox with Roads data
        jComboBoxRoad.addItem("A91");
        jComboBoxRoad.addItem("A81");
        jComboBoxRoad.addItem("A872");
        jComboBoxRoad.addItem("M9");
        jComboBoxRoad.addItem("M80");
        jComboBoxRoad.addItem("A84");
        jComboBoxRoad.addItem("A811");
        jComboBoxRoad.addItem("A9");
        jComboBoxRoad.addItem("A821");
        jComboBoxRoad.addItem("B8034");
        jComboBoxRoad.addItem("U");
        jComboBoxRoad.addItem("B829");
        jComboBoxRoad.addItem("B8051");
        jComboBoxRoad.addItem("A85");
        jComboBoxRoad.addItem("A873");
        jComboBoxRoad.addItem("A875");
        jComboBoxRoad.addItem("A827");
        jComboBoxRoad.addItem("A809");
        jComboBoxRoad.addItem("A82");
        jComboBoxRoad.addItem("C");
        jComboBoxRoad.addItem("A907");
        jComboBoxRoad.addItem("A820");
        jComboBoxRoad.addItem("A891");
        jComboBoxRoad.addItem("B823");
        jComboBoxRoad.addItem("B818");

        // Populate ComboBox with year
        jComboBoxYear.addItem("2000");
        jComboBoxYear.addItem("2001");
        jComboBoxYear.addItem("2002");
        jComboBoxYear.addItem("2003");
        jComboBoxYear.addItem("2004");
        jComboBoxYear.addItem("2005");
        jComboBoxYear.addItem("2006");
        jComboBoxYear.addItem("2007");
        jComboBoxYear.addItem("2008");
        jComboBoxYear.addItem("2009");
        jComboBoxYear.addItem("2010");
        jComboBoxYear.addItem("2011");
        jComboBoxYear.addItem("2012");
        jComboBoxYear.addItem("2013");
        jComboBoxYear.addItem("2014");
        jComboBoxYear.addItem("2015");
        jComboBoxYear.addItem("2016");
        jComboBoxYear.addItem("2017");
        jComboBoxYear.addItem("2018");
        jComboBoxYear.addItem("2019");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        leftPanel = new javax.swing.JPanel();
        adminPanelLabel = new javax.swing.JLabel();
        dash1Label = new javax.swing.JLabel();
        dash2Label = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        welcomeLabel = new javax.swing.JLabel();
        closeLabel = new javax.swing.JLabel();
        LayerdPanel = new javax.swing.JLayeredPane();
        adminPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        adminPanelTable = new javax.swing.JTable();
        checkActivityPanel2 = new javax.swing.JPanel();
        checkActivityLabel2 = new javax.swing.JLabel();
        giveAdminPanel = new javax.swing.JPanel();
        giveAdminLabel = new javax.swing.JLabel();
        removeAdminPanel = new javax.swing.JPanel();
        removeAdminLabel = new javax.swing.JLabel();
        deleteUserPanel = new javax.swing.JPanel();
        deleteUserLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dashboard1Panel = new javax.swing.JPanel();
        CenterPanel1 = new javax.swing.JPanel();
        CenterPanel2 = new javax.swing.JPanel();
        leftchart = new javax.swing.JPanel();
        righchart = new javax.swing.JPanel();
        rightsettings = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        cars = new javax.swing.JRadioButton();
        buses = new javax.swing.JRadioButton();
        leftsettings = new javax.swing.JPanel();
        two_d = new javax.swing.JRadioButton();
        three_d = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        road = new javax.swing.JCheckBox();
        day = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        dashboard2Panel = new javax.swing.JPanel();
        dashboard2Panel1 = new javax.swing.JPanel();
        CenterPanel3 = new javax.swing.JPanel();
        CenterPanel4 = new javax.swing.JPanel();
        leftchart1 = new javax.swing.JPanel();
        righchart1 = new javax.swing.JPanel();
        leftsettings1 = new javax.swing.JPanel();
        cars_and_taxis_radio = new javax.swing.JRadioButton();
        Buses_Coaches_radio = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        Motorbikes_radio = new javax.swing.JRadioButton();
        Cycles_radio = new javax.swing.JRadioButton();
        LGVs_radio = new javax.swing.JRadioButton();
        HGVs_radio = new javax.swing.JRadioButton();
        rightsettings1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jComboBoxRoad = new javax.swing.JComboBox<>();
        jComboBoxYear = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        leftPanel.setBackground(new java.awt.Color(51, 0, 102));

        adminPanelLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home/adminPanelIcon.png"))); // NOI18N
        adminPanelLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminPanelLabelMouseClicked(evt);
            }
        });

        dash1Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home/dash1Icon.png"))); // NOI18N
        dash1Label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dash1LabelMouseClicked(evt);
            }
        });

        dash2Label.setIcon(new javax.swing.ImageIcon("C:\\Users\\mitko\\OneDrive\\Desktop\\dash2.png")); // NOI18N
        dash2Label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dash2LabelMouseClicked(evt);
            }
        });

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home/logo2.png"))); // NOI18N

        javax.swing.GroupLayout leftPanelLayout = new javax.swing.GroupLayout(leftPanel);
        leftPanel.setLayout(leftPanelLayout);
        leftPanelLayout.setHorizontalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dash1Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dash2Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(adminPanelLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        leftPanelLayout.setVerticalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addGap(95, 95, 95)
                .addComponent(adminPanelLabel)
                .addGap(0, 0, 0)
                .addComponent(dash1Label)
                .addGap(0, 0, 0)
                .addComponent(dash2Label)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        rightPanel.setBackground(new java.awt.Color(186, 79, 84));

        welcomeLabel.setText("Welcome");

        closeLabel.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        closeLabel.setText("X");
        closeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeLabelMouseClicked(evt);
            }
        });

        adminPanel.setBackground(new java.awt.Color(186, 79, 84));
        adminPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        adminPanelTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "UserID", "Username", "User Email", "User Type", "Registration Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        adminPanelTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminPanelTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(adminPanelTable);

        checkActivityPanel2.setBackground(new java.awt.Color(186, 79, 84));
        checkActivityPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        checkActivityPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                checkActivityPanelMouseClicked(evt);
            }
        });

        checkActivityLabel2.setText(" Check User Activity");

        javax.swing.GroupLayout checkActivityPanel2Layout = new javax.swing.GroupLayout(checkActivityPanel2);
        checkActivityPanel2.setLayout(checkActivityPanel2Layout);
        checkActivityPanel2Layout.setHorizontalGroup(
            checkActivityPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(checkActivityLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
        );
        checkActivityPanel2Layout.setVerticalGroup(
            checkActivityPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(checkActivityLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
        );

        giveAdminPanel.setBackground(new java.awt.Color(186, 79, 84));
        giveAdminPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        giveAdminPanel.setForeground(new java.awt.Color(204, 204, 204));
        giveAdminPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                giveAdminPanelMouseClicked(evt);
            }
        });

        giveAdminLabel.setText(" Give Admin Rights");

        javax.swing.GroupLayout giveAdminPanelLayout = new javax.swing.GroupLayout(giveAdminPanel);
        giveAdminPanel.setLayout(giveAdminPanelLayout);
        giveAdminPanelLayout.setHorizontalGroup(
            giveAdminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(giveAdminLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
        );
        giveAdminPanelLayout.setVerticalGroup(
            giveAdminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(giveAdminLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        removeAdminPanel.setBackground(new java.awt.Color(186, 79, 84));
        removeAdminPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        removeAdminPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                removeAdminPanelMouseClicked(evt);
            }
        });

        removeAdminLabel.setText(" Remove Admin Rights");

        javax.swing.GroupLayout removeAdminPanelLayout = new javax.swing.GroupLayout(removeAdminPanel);
        removeAdminPanel.setLayout(removeAdminPanelLayout);
        removeAdminPanelLayout.setHorizontalGroup(
            removeAdminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(removeAdminLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
        );
        removeAdminPanelLayout.setVerticalGroup(
            removeAdminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(removeAdminLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        deleteUserPanel.setBackground(new java.awt.Color(186, 79, 84));
        deleteUserPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        deleteUserPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteUserPanelMouseClicked(evt);
            }
        });

        deleteUserLabel.setText("     Delete User");

        javax.swing.GroupLayout deleteUserPanelLayout = new javax.swing.GroupLayout(deleteUserPanel);
        deleteUserPanel.setLayout(deleteUserPanelLayout);
        deleteUserPanelLayout.setHorizontalGroup(
            deleteUserPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(deleteUserLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
        );
        deleteUserPanelLayout.setVerticalGroup(
            deleteUserPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(deleteUserLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
        );

        jLabel3.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        jLabel3.setText("Admin Panel");

        javax.swing.GroupLayout adminPanelLayout = new javax.swing.GroupLayout(adminPanel);
        adminPanel.setLayout(adminPanelLayout);
        adminPanelLayout.setHorizontalGroup(
            adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminPanelLayout.createSequentialGroup()
                .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(adminPanelLayout.createSequentialGroup()
                                .addComponent(deleteUserPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(removeAdminPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(giveAdminPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(checkActivityPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(adminPanelLayout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        adminPanelLayout.setVerticalGroup(
            adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminPanelLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel3)
                .addGap(41, 41, 41)
                .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(deleteUserPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(adminPanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(removeAdminPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(giveAdminPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(checkActivityPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        dashboard1Panel.setBackground(new java.awt.Color(186, 79, 84));

        CenterPanel2.setBackground(new java.awt.Color(255, 255, 204));

        leftchart.setLayout(new javax.swing.BoxLayout(leftchart, javax.swing.BoxLayout.LINE_AXIS));

        righchart.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                righchartComponentShown(evt);
            }
        });
        righchart.setLayout(new javax.swing.BoxLayout(righchart, javax.swing.BoxLayout.LINE_AXIS));

        javax.swing.GroupLayout CenterPanel2Layout = new javax.swing.GroupLayout(CenterPanel2);
        CenterPanel2.setLayout(CenterPanel2Layout);
        CenterPanel2Layout.setHorizontalGroup(
            CenterPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(leftchart, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(righchart, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                .addContainerGap())
        );
        CenterPanel2Layout.setVerticalGroup(
            CenterPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(CenterPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(leftchart, javax.swing.GroupLayout.DEFAULT_SIZE, 408, Short.MAX_VALUE)
                    .addComponent(righchart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(89, 89, 89))
        );

        rightsettings.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Select Time Range to Display:");

        jCheckBox1.setText("12AM - 4AM");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.setText("4AM - 8AM");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setText("8AM - 12PM");
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        jCheckBox4.setText("12PM - 4PM");
        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        jCheckBox5.setText("4PM - 8PM");
        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        jCheckBox6.setText("8PM - 12AM");
        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Select Vehicle to Display:");

        cars.setText("Cars and Taxis");
        cars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carsActionPerformed(evt);
            }
        });

        buses.setText("Buses and Coaches");
        buses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout rightsettingsLayout = new javax.swing.GroupLayout(rightsettings);
        rightsettings.setLayout(rightsettingsLayout);
        rightsettingsLayout.setHorizontalGroup(
            rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightsettingsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rightsettingsLayout.createSequentialGroup()
                        .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jCheckBox4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jCheckBox1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                            .addComponent(jCheckBox5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox3)
                            .addComponent(jCheckBox6)))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(rightsettingsLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(cars)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(buses)
                .addGap(38, 38, 38))
        );
        rightsettingsLayout.setVerticalGroup(
            rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightsettingsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cars)
                    .addComponent(buses))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox1)
                    .addComponent(jCheckBox2)
                    .addComponent(jCheckBox3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(rightsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox4)
                    .addComponent(jCheckBox5)
                    .addComponent(jCheckBox6))
                .addContainerGap())
        );

        leftsettings.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        two_d.setText("2D Chart");
        two_d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                two_dActionPerformed(evt);
            }
        });

        three_d.setText("3D chart");
        three_d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                three_dActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Select Chart type to Display:");

        road.setText(" Traffic by Road");
        road.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roadActionPerformed(evt);
            }
        });

        day.setText("Traffic During The Day");
        day.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dayActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Select Traffic Chart to Display:");

        javax.swing.GroupLayout leftsettingsLayout = new javax.swing.GroupLayout(leftsettings);
        leftsettings.setLayout(leftsettingsLayout);
        leftsettingsLayout.setHorizontalGroup(
            leftsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftsettingsLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(road)
                .addGap(18, 18, 18)
                .addComponent(day)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(leftsettingsLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(leftsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftsettingsLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(two_d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(three_d)
                        .addGap(50, 50, 50))
                    .addGroup(leftsettingsLayout.createSequentialGroup()
                        .addGroup(leftsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        leftsettingsLayout.setVerticalGroup(
            leftsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftsettingsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(13, 13, 13)
                .addGroup(leftsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(two_d)
                    .addComponent(three_d))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(leftsettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(road)
                    .addComponent(day))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout CenterPanel1Layout = new javax.swing.GroupLayout(CenterPanel1);
        CenterPanel1.setLayout(CenterPanel1Layout);
        CenterPanel1Layout.setHorizontalGroup(
            CenterPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(CenterPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CenterPanel1Layout.createSequentialGroup()
                        .addComponent(leftsettings, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(rightsettings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(CenterPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        CenterPanel1Layout.setVerticalGroup(
            CenterPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(CenterPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CenterPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rightsettings, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(leftsettings, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout dashboard1PanelLayout = new javax.swing.GroupLayout(dashboard1Panel);
        dashboard1Panel.setLayout(dashboard1PanelLayout);
        dashboard1PanelLayout.setHorizontalGroup(
            dashboard1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboard1PanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(CenterPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        dashboard1PanelLayout.setVerticalGroup(
            dashboard1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboard1PanelLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(CenterPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        dashboard2Panel.setBackground(new java.awt.Color(186, 79, 84));

        dashboard2Panel1.setBackground(new java.awt.Color(186, 79, 84));

        CenterPanel4.setBackground(new java.awt.Color(255, 255, 204));

        leftchart1.setLayout(new javax.swing.BoxLayout(leftchart1, javax.swing.BoxLayout.LINE_AXIS));

        righchart1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                righchart1ComponentShown(evt);
            }
        });
        righchart1.setLayout(new javax.swing.BoxLayout(righchart1, javax.swing.BoxLayout.LINE_AXIS));

        javax.swing.GroupLayout CenterPanel4Layout = new javax.swing.GroupLayout(CenterPanel4);
        CenterPanel4.setLayout(CenterPanel4Layout);
        CenterPanel4Layout.setHorizontalGroup(
            CenterPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(leftchart1, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(righchart1, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                .addContainerGap())
        );
        CenterPanel4Layout.setVerticalGroup(
            CenterPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CenterPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(righchart1, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                    .addComponent(leftchart1, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
                .addContainerGap())
        );

        leftsettings1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        cars_and_taxis_radio.setText("Cars & Taxis");
        cars_and_taxis_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cars_and_taxis_radioActionPerformed(evt);
            }
        });

        Buses_Coaches_radio.setText("Buses & Coaches");
        Buses_Coaches_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Buses_Coaches_radioActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("Select Vehicle type to Display:");

        Motorbikes_radio.setText("Motorbikes");
        Motorbikes_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Motorbikes_radioActionPerformed(evt);
            }
        });

        Cycles_radio.setText("Cycles");
        Cycles_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cycles_radioActionPerformed(evt);
            }
        });

        LGVs_radio.setText("LGVs");
        LGVs_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LGVs_radioActionPerformed(evt);
            }
        });

        HGVs_radio.setText("HGVs");
        HGVs_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HGVs_radioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout leftsettings1Layout = new javax.swing.GroupLayout(leftsettings1);
        leftsettings1.setLayout(leftsettings1Layout);
        leftsettings1Layout.setHorizontalGroup(
            leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftsettings1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(leftsettings1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(leftsettings1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cars_and_taxis_radio)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, leftsettings1Layout.createSequentialGroup()
                                .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LGVs_radio, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Motorbikes_radio, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(6, 6, 6)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Buses_Coaches_radio)
                            .addComponent(Cycles_radio)
                            .addComponent(HGVs_radio))
                        .addGap(50, 50, 50))))
        );
        leftsettings1Layout.setVerticalGroup(
            leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftsettings1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addGap(13, 13, 13)
                .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cars_and_taxis_radio)
                    .addComponent(Buses_Coaches_radio))
                .addGap(13, 13, 13)
                .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cycles_radio)
                    .addComponent(Motorbikes_radio))
                .addGap(13, 13, 13)
                .addGroup(leftsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(HGVs_radio)
                    .addComponent(LGVs_radio))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        rightsettings1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Select Road data to Display:");

        jComboBoxRoad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A905" }));
        jComboBoxRoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxRoadActionPerformed(evt);
            }
        });

        jComboBoxYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2000" }));
        jComboBoxYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxYearActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("Select Year data to Display:");

        javax.swing.GroupLayout rightsettings1Layout = new javax.swing.GroupLayout(rightsettings1);
        rightsettings1.setLayout(rightsettings1Layout);
        rightsettings1Layout.setHorizontalGroup(
            rightsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightsettings1Layout.createSequentialGroup()
                .addGroup(rightsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rightsettings1Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addGroup(rightsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBoxYear, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxRoad, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(rightsettings1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(rightsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9))))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        rightsettings1Layout.setVerticalGroup(
            rightsettings1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightsettings1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(jComboBoxRoad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addGap(15, 15, 15)
                .addComponent(jComboBoxYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(111, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout CenterPanel3Layout = new javax.swing.GroupLayout(CenterPanel3);
        CenterPanel3.setLayout(CenterPanel3Layout);
        CenterPanel3Layout.setHorizontalGroup(
            CenterPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(CenterPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CenterPanel3Layout.createSequentialGroup()
                        .addComponent(CenterPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(49, Short.MAX_VALUE))
                    .addGroup(CenterPanel3Layout.createSequentialGroup()
                        .addComponent(leftsettings1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                        .addComponent(rightsettings1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        CenterPanel3Layout.setVerticalGroup(
            CenterPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CenterPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(CenterPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20)
                .addGroup(CenterPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(leftsettings1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rightsettings1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout dashboard2Panel1Layout = new javax.swing.GroupLayout(dashboard2Panel1);
        dashboard2Panel1.setLayout(dashboard2Panel1Layout);
        dashboard2Panel1Layout.setHorizontalGroup(
            dashboard2Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboard2Panel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(CenterPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        dashboard2Panel1Layout.setVerticalGroup(
            dashboard2Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboard2Panel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(CenterPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout dashboard2PanelLayout = new javax.swing.GroupLayout(dashboard2Panel);
        dashboard2Panel.setLayout(dashboard2PanelLayout);
        dashboard2PanelLayout.setHorizontalGroup(
            dashboard2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 766, Short.MAX_VALUE)
            .addGroup(dashboard2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(dashboard2PanelLayout.createSequentialGroup()
                    .addGap(3, 3, 3)
                    .addComponent(dashboard2Panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(4, 4, 4)))
        );
        dashboard2PanelLayout.setVerticalGroup(
            dashboard2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 699, Short.MAX_VALUE)
            .addGroup(dashboard2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(dashboard2PanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(dashboard2Panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        LayerdPanel.setLayer(adminPanel, javax.swing.JLayeredPane.DEFAULT_LAYER);
        LayerdPanel.setLayer(dashboard1Panel, javax.swing.JLayeredPane.DEFAULT_LAYER);
        LayerdPanel.setLayer(dashboard2Panel, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout LayerdPanelLayout = new javax.swing.GroupLayout(LayerdPanel);
        LayerdPanel.setLayout(LayerdPanelLayout);
        LayerdPanelLayout.setHorizontalGroup(
            LayerdPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LayerdPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(162, Short.MAX_VALUE))
            .addGroup(LayerdPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(LayerdPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(dashboard1Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(LayerdPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LayerdPanelLayout.createSequentialGroup()
                    .addComponent(dashboard2Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        LayerdPanelLayout.setVerticalGroup(
            LayerdPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LayerdPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
            .addGroup(LayerdPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(LayerdPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(dashboard1Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(LayerdPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LayerdPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(dashboard2Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout rightPanelLayout = new javax.swing.GroupLayout(rightPanel);
        rightPanel.setLayout(rightPanelLayout);
        rightPanelLayout.setHorizontalGroup(
            rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(welcomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 710, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(closeLabel)
                .addGap(8, 8, 8))
            .addGroup(rightPanelLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(LayerdPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        rightPanelLayout.setVerticalGroup(
            rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightPanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(welcomeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(closeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LayerdPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(leftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(rightPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(leftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 753, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void closeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseClicked
        //log out user on exit
        logOutUser();
    }//GEN-LAST:event_closeLabelMouseClicked
    //delete user function
    private void deleteUserPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteUserPanelMouseClicked
        int n = JOptionPane.showConfirmDialog(
                null, "Are you sure you want to delete this user?",
                "Delete User",
                JOptionPane.YES_NO_OPTION);
        switch (n) {
            case JOptionPane.YES_OPTION:
                try {
                    String sqlQuery = ("DELETE FROM Users WHERE userId = ?");

                    Connection con = connectDB.getConnection();
                    PreparedStatement pst = con.prepareStatement(sqlQuery);

                    pst.setInt(1, tc_id);
                    pst.executeUpdate();

                    pst.close();
                    con.close();

                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e.toString());
                }
                deleteRow();
                break;
            case JOptionPane.NO_OPTION:
                break;
            default:
                break;
        }
    }//GEN-LAST:event_deleteUserPanelMouseClicked
    //remove admin rights function
    private void removeAdminPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_removeAdminPanelMouseClicked
        int n = JOptionPane.showConfirmDialog(
                null, "Are you sure you want to remove admin rights for this user?",
                "Admin rights",
                JOptionPane.YES_NO_OPTION);
        switch (n) {
            case JOptionPane.YES_OPTION:
                try {
                    String sqlQuery = ("UPDATE Users SET userType = ? WHERE userId = ?");

                    Connection con = connectDB.getConnection();
                    PreparedStatement pst = con.prepareStatement(sqlQuery);

                    pst.setString(1, "C");
                    pst.setInt(2, tc_id);
                    pst.executeUpdate();

                    pst.close();
                    con.close();

                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e.toString());
                }
                DefaultTableModel tm = (DefaultTableModel) adminPanelTable.getModel();
                tm.setValueAt("C", row, 3);
                break;
            case JOptionPane.NO_OPTION:
                break;
            default:
                break;
        }
    }//GEN-LAST:event_removeAdminPanelMouseClicked
    //give admin rights function
    private void giveAdminPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_giveAdminPanelMouseClicked
        int n = JOptionPane.showConfirmDialog(
                null, "Are you sure you want to give admin rights to this user?",
                "Admin rights",
                JOptionPane.YES_NO_OPTION);
        switch (n) {
            case JOptionPane.YES_OPTION:
                try {
                    String sqlQuery = ("UPDATE Users SET userType = ? WHERE userId = ?");

                    Connection con = connectDB.getConnection();
                    PreparedStatement pst = con.prepareStatement(sqlQuery);

                    pst.setString(1, "A");
                    pst.setInt(2, tc_id);
                    pst.executeUpdate();

                    pst.close();
                    con.close();

                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e.toString());
                }
                DefaultTableModel tm = (DefaultTableModel) adminPanelTable.getModel();
                tm.setValueAt("A", row, 3);
                break;
            case JOptionPane.NO_OPTION:
                break;
            default:
                break;
        }
    }//GEN-LAST:event_giveAdminPanelMouseClicked
    //check user activity function
    private void checkActivityPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkActivityPanelMouseClicked
        Connection con = connectDB.getConnection();
        Statement stmt = null;//con.createStatement();
        ResultSet rs = null;
        if (tc_id != null) {
            try {

                String sql = "select * from Users_Activity where userId=" + tc_id;
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);

                String userActivityMsg = "";

                while (rs.next()) {

                    int id = rs.getInt("userId");
                    String logInDate = rs.getString("logInDateTime");
                    String logOutDate = rs.getString("logOutDateTime");

                    userActivityMsg += ("<html><strong>User ID: </strong>" + id + " <strong>Log in Date/Time:</strong> " + logInDate + " <strong>Log Out Date/Time:</strong> " + logOutDate + "\n");
                }

                if (userActivityMsg.equals("")) {
                    JOptionPane.showMessageDialog(null, "No user activity yet!");
                } else {
                    JOptionPane.showMessageDialog(null, userActivityMsg);
                }
                rs.close();
                stmt.close();
                con.close();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            JOptionPane.showMessageDialog(null, "You need to select a user from the table");
        }
    }//GEN-LAST:event_checkActivityPanelMouseClicked
    //on table click
    private void adminPanelTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminPanelTableMouseClicked
        // TODO add your handling code here:
        row = adminPanelTable.getSelectedRow();

        tc_id = Integer.parseInt((String) adminPanelTable.getModel().getValueAt(row, 0));
    }//GEN-LAST:event_adminPanelTableMouseClicked

    private void adminPanelLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminPanelLabelMouseClicked
        toggleAdminPanel();
    }//GEN-LAST:event_adminPanelLabelMouseClicked

    private void dash1LabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dash1LabelMouseClicked
        toggleDash1();
    }//GEN-LAST:event_dash1LabelMouseClicked

    private void dash2LabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dash2LabelMouseClicked
        toggleDash2();
    }//GEN-LAST:event_dash2LabelMouseClicked

    private void righchartComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_righchartComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_righchartComponentShown

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:

        if (cars.isSelected()) {
            // car traffic between 12am to 4m
            if (jCheckBox1.isSelected()) {
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);

                try {
                    String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 0 AND 3";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 12AM to 4AM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox1.setSelected(true);

            }
        } else if (buses.isSelected()) {
            //uncheck others buttons
            if (jCheckBox1.isSelected()) {
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 0 AND 3";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 12AM to 4AM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {
                jCheckBox1.setSelected(true);

            }

        }

    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
        if (cars.isSelected()) {
            // car traffic between 4am to 8am
            if (jCheckBox2.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 4 AND 7";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 4AM to 8AM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }
            } else {

                jCheckBox2.setSelected(true);

            }
        } else if (buses.isSelected()) {

            if (jCheckBox2.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 4 AND 7";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 4AM to 8AM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }
            } else {

                jCheckBox2.setSelected(true);

            }

        }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        // TODO add your handling code here:
        if (cars.isSelected()) {
            // car traffic between 8am to 12pm
            if (jCheckBox3.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 8 AND 11";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 8AM to 12PM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox3.setSelected(true);
            }
        } else if (buses.isSelected()) {
            if (jCheckBox3.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 8 AND 11";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 8AM to 12PM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox3.setSelected(true);
            }

        }
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        // TODO add your handling code here:
        // car traffic between 12pm to 4pm
        if (cars.isSelected()) {
            if (jCheckBox4.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 12 AND 15";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 12PM to 4PM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox4.setSelected(true);
            }
        } else if (buses.isSelected()) {

            if (jCheckBox4.isSelected()) {

                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 12 AND 15";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 12PM to 4PM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {
                jCheckBox4.setSelected(true);
            }

        }
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        // TODO add your handling code here:
        // car traffic between 4pm to 8pm
        if (cars.isSelected()) {
            if (jCheckBox5.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 16 AND 19";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 4PM to 8PM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox5.setSelected(true);
            }
        } else if (buses.isSelected()) {

            if (jCheckBox5.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox6.setSelected(false);
                try {
                    String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 16 AND 19";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 4PM to 8PM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox5.setSelected(true);
            }
        }
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        // TODO add your handling code here:
        // car traffic between 8pm to 12am
        if (cars.isSelected()) {
            if (jCheckBox6.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                try {
                    String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 20 AND 23";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 8PM to 12AM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox6.setSelected(true);
            }
        } else if (buses.isSelected()) {

            if (jCheckBox6.isSelected()) {
                //uncheck others checkboxes
                jCheckBox1.setSelected(false);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                try {
                    String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 20 AND 23";
                    JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                    JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 8PM to 12AM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                    BarRenderer renderer = null;
                    CategoryPlot plot = null;
                    renderer = new BarRenderer();
                    //creates new frame to display the chart
                    //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                    //frame.setVisible(true);
                    //frame.setSize(400, 650);
                    //Add it to the panel
                    ChartPanel chartPanel = new ChartPanel(chartv);

                    righchart.removeAll();
                    righchart.add(chartPanel);
                    righchart.updateUI();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

            } else {

                jCheckBox6.setSelected(true);
            }
        }
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void carsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carsActionPerformed

        if (cars.isSelected()) {
            try {
                // TODO add your handling code here:
                buses.setSelected(false);
                jCheckBox1.setSelected(true);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);

                //chart
                String query = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 0 AND 3";
                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                JFreeChart chartv = ChartFactory.createBarChart("Car Traffic Between 12AM to 4AM", "Hours", "Cars and taxis", dataset, PlotOrientation.VERTICAL, false, true, true);
                BarRenderer renderer = null;
                CategoryPlot plot = null;
                renderer = new BarRenderer();
                //creates new frame to display the chart
                //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                //frame.setVisible(true);
                //frame.setSize(400, 650);
                //Add it to the panel
                ChartPanel chartPanel = new ChartPanel(chartv);

                righchart.removeAll();
                righchart.add(chartPanel);
                righchart.updateUI();
            } catch (SQLException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            cars.setSelected(true);
        }
    }//GEN-LAST:event_carsActionPerformed

    private void busesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busesActionPerformed

        if (buses.isSelected()) {
            try {
                // TODO add your handling code here:

                cars.setSelected(false);
                jCheckBox1.setSelected(true);
                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                //chart
                String query = "select hour,buses_and_coaches from Count_Point Where hour BETWEEN 0 AND 3";
                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                JFreeChart chartv = ChartFactory.createBarChart("Bus Traffic Between 12AM to 4AM", "Hours", "Buses and Coaches", dataset, PlotOrientation.VERTICAL, false, true, true);
                BarRenderer renderer = null;
                CategoryPlot plot = null;
                renderer = new BarRenderer();
                //creates new frame to display the chart
                //ChartFrame frame = new ChartFrame("Query Chart", chartv); //title of the frame
                //frame.setVisible(true);
                //frame.setSize(400, 650);
                //Add it to the panel
                ChartPanel chartPanel = new ChartPanel(chartv);

                righchart.removeAll();
                righchart.add(chartPanel);
                righchart.updateUI();
            } catch (SQLException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            buses.setSelected(true);
        }

    }//GEN-LAST:event_busesActionPerformed

    private void two_dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_two_dActionPerformed

        if (two_d.isSelected()) {
            try {

                // TODO add your handling code here:
                three_d.setSelected(false);
                road.setSelected(true);
                day.setSelected(false);

                //______________________________________________________________________________________________________________________________
                //_______________________________________________________________________________________________________________________________
                //create Pie chart
                String piequery = "select road_name,cars_and_taxis from Count_Point";
                JDBCPieDataset pieDataset = new JDBCPieDataset("jdbc:sqlite:SQLite Group 5CS05.db", "org.sqlite.JDBC",
                        "root", "root");
                pieDataset.executeQuery(piequery);

                JFreeChart chart = ChartFactory.createPieChart("General Traffic by Road", pieDataset, true, true, true);
                PiePlot P = (PiePlot) chart.getPlot();
                //P.setForegroundAlpha(TOP_ALIGNMENT);

                //Add it to the panel
                ChartPanel chartPanel2 = new ChartPanel(chart);
                leftchart.removeAll();
                leftchart.add(chartPanel2);
                leftchart.updateUI();

            } catch (SQLException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            two_d.setSelected(true);
        }

    }//GEN-LAST:event_two_dActionPerformed

    private void three_dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_three_dActionPerformed

        if (three_d.isSelected()) {
            try {
                // TODO add your handling code here:
                two_d.setSelected(false);
                road.setSelected(true);
                day.setSelected(false);

                //______________________________________________________________________________________________________________________________
                //_______________________________________________________________________________________________________________________________
                //create Pie chart
                String piequery = "select road_name,cars_and_taxis from Count_Point";
                JDBCPieDataset pieDataset = new JDBCPieDataset("jdbc:sqlite:SQLite Group 5CS05.db", "org.sqlite.JDBC",
                        "root", "root");
                pieDataset.executeQuery(piequery);

                JFreeChart chart = ChartFactory.createPieChart3D("General Traffic by Road", pieDataset, true, true, true);
                PiePlot3D P = (PiePlot3D) chart.getPlot();
                //P.setForegroundAlpha(TOP_ALIGNMENT);

                //Add it to the panel
                ChartPanel chartPanel2 = new ChartPanel(chart);
                leftchart.removeAll();
                leftchart.add(chartPanel2);
                leftchart.updateUI();

            } catch (SQLException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            three_d.setSelected(true);
        }
    }//GEN-LAST:event_three_dActionPerformed

    private void roadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roadActionPerformed
        if (road.isSelected()) {
            day.setSelected(false);
            if (two_d.isSelected()) {

                try {
                    // TODO add your handling code here:
                    //create Pie chart
                    String piequery = "select road_name,cars_and_taxis from Count_Point";
                    JDBCPieDataset pieDataset = new JDBCPieDataset("jdbc:sqlite:SQLite Group 5CS05.db", "org.sqlite.JDBC",
                            "root", "root");
                    pieDataset.executeQuery(piequery);

                    JFreeChart chart = ChartFactory.createPieChart("General Traffic by Road", pieDataset, true, true, true);
                    PiePlot P = (PiePlot) chart.getPlot();
                    //P.setForegroundAlpha(TOP_ALIGNMENT);

                    //Add it to the panel
                    ChartPanel chartPanel2 = new ChartPanel(chart);
                    leftchart.removeAll();
                    leftchart.add(chartPanel2);
                    leftchart.updateUI();
                } catch (SQLException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                try {

                    //3DPieChart
                    String piequery = "select road_name,cars_and_taxis from Count_Point";
                    JDBCPieDataset pieDataset = new JDBCPieDataset("jdbc:sqlite:SQLite Group 5CS05.db", "org.sqlite.JDBC",
                            "root", "root");
                    pieDataset.executeQuery(piequery);

                    JFreeChart chart = ChartFactory.createPieChart3D("General Traffic by Road", pieDataset, true, true, true);
                    PiePlot3D P = (PiePlot3D) chart.getPlot();
                    //P.setForegroundAlpha(TOP_ALIGNMENT);

                    //Add it to the panel
                    ChartPanel chartPanel2 = new ChartPanel(chart);
                    leftchart.removeAll();
                    leftchart.add(chartPanel2);
                    leftchart.updateUI();
                } catch (SQLException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            road.setSelected(true);
        }

    }//GEN-LAST:event_roadActionPerformed

    private void dayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dayActionPerformed
        // TODO add your handling code here:
        if (day.isSelected()) {
            road.setSelected(false);
            if (two_d.isSelected()) {
                try {
                    // TODO add your handling code here:
                    //create Pie chart
                    String piequery = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 0 AND 23";
                    JDBCPieDataset pieDataset = new JDBCPieDataset("jdbc:sqlite:SQLite Group 5CS05.db", "org.sqlite.JDBC",
                            "root", "root");
                    pieDataset.executeQuery(piequery);

                    JFreeChart chart = ChartFactory.createPieChart("Traffic During the Day Per Hour", pieDataset, true, true, true);
                    PiePlot P = (PiePlot) chart.getPlot();
                    //P.setForegroundAlpha(TOP_ALIGNMENT);

                    //Add it to the panel
                    ChartPanel chartPanel2 = new ChartPanel(chart);
                    leftchart.removeAll();
                    leftchart.add(chartPanel2);
                    leftchart.updateUI();
                } catch (SQLException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                try {
                    //3DPieChart
                    String piequery = "select hour,cars_and_taxis from Count_Point Where hour BETWEEN 0 AND 23";
                    JDBCPieDataset pieDataset = new JDBCPieDataset("jdbc:sqlite:SQLite Group 5CS05.db", "org.sqlite.JDBC",
                            "root", "root");
                    pieDataset.executeQuery(piequery);

                    JFreeChart chart = ChartFactory.createPieChart3D("Traffic during the day Per Hour", pieDataset, true, true, true);
                    PiePlot3D P = (PiePlot3D) chart.getPlot();
                    //P.setForegroundAlpha(TOP_ALIGNMENT);

                    //Add it to the panel
                    ChartPanel chartPanel2 = new ChartPanel(chart);
                    leftchart.removeAll();
                    leftchart.add(chartPanel2);
                    leftchart.updateUI();
                } catch (SQLException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            day.setSelected(true);
        }

    }//GEN-LAST:event_dayActionPerformed

    private void righchart1ComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_righchart1ComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_righchart1ComponentShown

    private void cars_and_taxis_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cars_and_taxis_radioActionPerformed

        if (cars_and_taxis_radio.isSelected()) {
            Buses_Coaches_radio.setSelected(false);
            Motorbikes_radio.setSelected(false);
            Cycles_radio.setSelected(false);
            HGVs_radio.setSelected(false);
            LGVs_radio.setSelected(false);
            try {

                String query = "select year, sum(cars_and_taxis) Cars from count_point group by year ";
                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total Cars and Taxis Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                final CategoryPlot plot = chart.getCategoryPlot();
                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //Buses_Coaches_radio.setSelected(false);
        }
    }//GEN-LAST:event_cars_and_taxis_radioActionPerformed

    private void Buses_Coaches_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Buses_Coaches_radioActionPerformed

        // If checked then run relevant SQL query
        if (Buses_Coaches_radio.isSelected()) {
            cars_and_taxis_radio.setSelected(false);
            Motorbikes_radio.setSelected(false);
            Cycles_radio.setSelected(false);
            HGVs_radio.setSelected(false);
            LGVs_radio.setSelected(false);
            try {
                String query = "select year, sum(buses_and_coaches) 'Buses and Coaches' from count_point group by year ";

                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);

                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total Buses and Coaches Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //cars_and_taxis_radio.setSelected(false);
        }
    }//GEN-LAST:event_Buses_Coaches_radioActionPerformed

    private void Motorbikes_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Motorbikes_radioActionPerformed

        // If checked then run relevant SQL query
        if (Motorbikes_radio.isSelected()) {
            cars_and_taxis_radio.setSelected(false);
            Buses_Coaches_radio.setSelected(false);
            Cycles_radio.setSelected(false);
            HGVs_radio.setSelected(false);
            LGVs_radio.setSelected(false);

            try {
                String query = "select year, sum(two_wheeled_motor_vehicles) Motorbikes from count_point group by year ";

                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);

                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total Motorbikes Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //cars_and_taxis_radio.setSelected(false);
        }    // TODO add your handling code here:
    }//GEN-LAST:event_Motorbikes_radioActionPerformed

    private void Cycles_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cycles_radioActionPerformed

        // If checked then run relevant SQL query
        if (Cycles_radio.isSelected()) {
            cars_and_taxis_radio.setSelected(false);
            Buses_Coaches_radio.setSelected(false);
            Motorbikes_radio.setSelected(false);
            HGVs_radio.setSelected(false);
            LGVs_radio.setSelected(false);

            try {
                String query = "select year, sum(pedal_cycles) Cycles from count_point group by year ";

                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);

                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total Pedal Cycles Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //cars_and_taxis_radio.setSelected(false);
        }    // TODO add your handling code here:    // TODO add your handling code here:
    }//GEN-LAST:event_Cycles_radioActionPerformed

    private void LGVs_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LGVs_radioActionPerformed
        // TODO add your handling code here:

        // If checked then run relevant SQL query
        if (LGVs_radio.isSelected()) {
            cars_and_taxis_radio.setSelected(false);
            Buses_Coaches_radio.setSelected(false);
            Motorbikes_radio.setSelected(false);
            Cycles_radio.setSelected(false);
            HGVs_radio.setSelected(false);

            try {
                String query = "select year, sum(lgvs) LGVs from count_point group by year ";

                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);

                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total LGV Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //cars_and_taxis_radio.setSelected(false);
        }    // TODO add your handling code here:    // TODO add your handling code here:
    }//GEN-LAST:event_LGVs_radioActionPerformed

    private void HGVs_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HGVs_radioActionPerformed
        // TODO add your handling code here:

        // If checked then run relevant SQL query
        if (HGVs_radio.isSelected()) {
            cars_and_taxis_radio.setSelected(false);
            Buses_Coaches_radio.setSelected(false);
            Motorbikes_radio.setSelected(false);
            Cycles_radio.setSelected(false);
            LGVs_radio.setSelected(false);
            try {
                String query = "select year, sum(hgvs_2_rigid_axle)+sum(hgvs_3_rigid_axle)+"
                        + "sum(hgvs_4_or_more_rigid_axle)+sum(hgvs_3_or_4_articulated_axle)+"
                        + "sum(hgvs_5_articulated_axle)+sum(hgvs_6_articulated_axle) HGVs "
                        + "from count_point group by year ";

                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);

                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total HGV Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //cars_and_taxis_radio.setSelected(false);
        }    // TODO add your handling code here:    // TODO add your handling code here:    // TODO add your handling code here:
    }//GEN-LAST:event_HGVs_radioActionPerformed

    private void jComboBoxRoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxRoadActionPerformed
        // TODO add your handling code here:
        RoadName = jComboBoxRoad.getSelectedItem().toString();

        try {
            String query = "select hour, sum(pedal_cycles) + sum(cars_and_taxis) + "
                    + "sum(two_wheeled_motor_vehicles) + sum(buses_and_coaches) + sum(lgvs) + "
                    + "sum(hgvs_2_rigid_axle)+sum(hgvs_3_rigid_axle)+"
                    + "sum(hgvs_4_or_more_rigid_axle)+sum(hgvs_3_or_4_articulated_axle)+"
                    + "sum(hgvs_5_articulated_axle)+sum(hgvs_6_articulated_axle)"
                    + "Vehicles from count_point"
                    + " where road_name = '" + RoadName
                    + "' and year = " + Year + " group by hour, year ";
            System.out.println("query " + query);
            JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
            JFreeChart chart = ChartFactory.createLineChart(
                    "Total Traffic by year for Road " + RoadName + " Year " + Year, "Year " + Year, "Total Vehicle Count",
                    dataset, PlotOrientation.HORIZONTAL, true, true, false);

            final CategoryPlot plot = chart.getCategoryPlot();
            ChartPanel cp = new ChartPanel(chart);

            righchart1.removeAll();
            righchart1.add(cp);
            righchart1.updateUI();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }

    }//GEN-LAST:event_jComboBoxRoadActionPerformed

    private void jComboBoxYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxYearActionPerformed
        // TODO add your handling code here:
        Year = jComboBoxYear.getSelectedItem().toString();

        try {
            String query = "select hour, sum(pedal_cycles) + sum(cars_and_taxis) + "
                    + "sum(two_wheeled_motor_vehicles) + sum(buses_and_coaches) + sum(lgvs) + "
                    + "sum(hgvs_2_rigid_axle)+sum(hgvs_3_rigid_axle)+"
                    + "sum(hgvs_4_or_more_rigid_axle)+sum(hgvs_3_or_4_articulated_axle)+"
                    + "sum(hgvs_5_articulated_axle)+sum(hgvs_6_articulated_axle)"
                    + "Vehicles from count_point"
                    + " where road_name = '" + RoadName
                    + "' and year = " + Year + " group by hour, year ";
            System.out.println("query " + query);
            JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
            JFreeChart chart = ChartFactory.createLineChart(
                    "Total Traffic by year for Road " + RoadName, "Year " + Year, "Total Vehicle Count",
                    dataset, PlotOrientation.HORIZONTAL, true, true, false);

            final CategoryPlot plot = chart.getCategoryPlot();
            ChartPanel cp = new ChartPanel(chart);

            righchart1.removeAll();
            righchart1.add(cp);
            righchart1.updateUI();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_jComboBoxYearActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:

        // Populate ComboBox1 with roads
        PopulateComboBox1();

        // Populate left graph on form entry
        

        // If checked then run relevant SQL query
        if (cars_and_taxis_radio.isSelected()) {
            Buses_Coaches_radio.setSelected(false);
            Motorbikes_radio.setSelected(false);
            Cycles_radio.setSelected(false);
            try {

                String query = "select year, sum(cars_and_taxis) Cars from count_point group by year ";
                JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
                JFreeChart chart = ChartFactory.createLineChart(
                        "Total Traffic by year", "Year", "Total Vehicle Count",
                        dataset, PlotOrientation.HORIZONTAL, true, true, false);

                final CategoryPlot plot = chart.getCategoryPlot();
                ChartPanel cp = new ChartPanel(chart);

                leftchart1.removeAll();
                leftchart1.add(cp);
                leftchart1.updateUI();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }

        } else {
            //Buses_Coaches_radio.setSelected(false);
        }

        // Populate right chart
        try {
            String query = "select hour, sum(pedal_cycles) + sum(cars_and_taxis) + "
                    + "sum(two_wheeled_motor_vehicles) + sum(buses_and_coaches) + sum(lgvs) + "
                    + "sum(hgvs_2_rigid_axle)+sum(hgvs_3_rigid_axle)+"
                    + "sum(hgvs_4_or_more_rigid_axle)+sum(hgvs_3_or_4_articulated_axle)+"
                    + "sum(hgvs_5_articulated_axle)+sum(hgvs_6_articulated_axle)"
                    + "Vehicles from count_point"
                    + " where road_name = '" + RoadName
                    + "' and year = " + Year + " group by hour, year ";
            System.out.println("query " + query);
            JDBCCategoryDataset dataset = new JDBCCategoryDataset(connectDB.getConnection2(), query);
            JFreeChart chart = ChartFactory.createLineChart(
                    "Total Traffic by year for Road " + RoadName + " Year " + Year, "Year " + Year, "Total Vehicle Count",
                    dataset, PlotOrientation.HORIZONTAL, true, true, false);

            final CategoryPlot plot = chart.getCategoryPlot();
            ChartPanel cp = new ChartPanel(chart);

            righchart1.removeAll();
            righchart1.add(cp);
            righchart1.updateUI();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_formWindowActivated

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Buses_Coaches_radio;
    private javax.swing.JPanel CenterPanel1;
    private javax.swing.JPanel CenterPanel2;
    private javax.swing.JPanel CenterPanel3;
    private javax.swing.JPanel CenterPanel4;
    private javax.swing.JRadioButton Cycles_radio;
    private javax.swing.JRadioButton HGVs_radio;
    private javax.swing.JRadioButton LGVs_radio;
    private javax.swing.JLayeredPane LayerdPanel;
    private javax.swing.JRadioButton Motorbikes_radio;
    private javax.swing.JPanel adminPanel;
    private javax.swing.JLabel adminPanelLabel;
    private javax.swing.JTable adminPanelTable;
    private javax.swing.JRadioButton buses;
    private javax.swing.JRadioButton cars;
    private javax.swing.JRadioButton cars_and_taxis_radio;
    private javax.swing.JLabel checkActivityLabel2;
    private javax.swing.JPanel checkActivityPanel2;
    private javax.swing.JLabel closeLabel;
    private javax.swing.JLabel dash1Label;
    private javax.swing.JLabel dash2Label;
    private javax.swing.JPanel dashboard1Panel;
    private javax.swing.JPanel dashboard2Panel;
    private javax.swing.JPanel dashboard2Panel1;
    private javax.swing.JCheckBox day;
    private javax.swing.JLabel deleteUserLabel;
    private javax.swing.JPanel deleteUserPanel;
    private javax.swing.JLabel giveAdminLabel;
    private javax.swing.JPanel giveAdminPanel;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JComboBox<String> jComboBoxRoad;
    private javax.swing.JComboBox<String> jComboBoxYear;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel leftchart;
    private javax.swing.JPanel leftchart1;
    private javax.swing.JPanel leftsettings;
    private javax.swing.JPanel leftsettings1;
    private javax.swing.JLabel removeAdminLabel;
    private javax.swing.JPanel removeAdminPanel;
    private javax.swing.JPanel righchart;
    private javax.swing.JPanel righchart1;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JPanel rightsettings;
    private javax.swing.JPanel rightsettings1;
    private javax.swing.JCheckBox road;
    private javax.swing.JRadioButton three_d;
    private javax.swing.JRadioButton two_d;
    private javax.swing.JLabel welcomeLabel;
    // End of variables declaration//GEN-END:variables
}
