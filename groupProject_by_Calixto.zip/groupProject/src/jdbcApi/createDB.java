/* CreatDB.java code */
package jdbcApi;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.logging.Logger;

/**
 *
 * @author glukka
 */
public class createDB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Connect();
    }
}

class Connect {

    private String urlSQLite;
    private Driver driverSQLite;
    private Connection conSQLite;
    //__________________________
    private String urlSQLite2;
    private Driver driverSQLite2;
    private Connection conSQLite2;

    public Connect() {
        urlSQLite = "jdbc:sqlite:company.db";
        urlSQLite2 = "jdbc:sqlite:SQLite Group 5CS05.db";

        try {
            driverSQLite = new org.sqlite.JDBC();
            driverSQLite2 = new org.sqlite.JDBC();
            DriverManager.registerDriver(driverSQLite);
            DriverManager.registerDriver(driverSQLite2);
            System.out.println("Driver for SQLite downloaded.");
            System.out.println("Driver for SQLite2 downloaded.");
        } catch (Exception e) {
            System.out.println("Problem with download driver for SQLite: " + e.getMessage());
        }

        try {
            conSQLite = DriverManager.getConnection(urlSQLite);
            conSQLite2 = DriverManager.getConnection(urlSQLite2);
            System.out.println("Connection to SQLite is done.");
            System.out.println("Connection to SQLite2 is done.");
        } catch (Exception e) {
            System.out.println("Problem with connection to SQLite: " + e.getMessage());
        }

        try {
            if (!conSQLite.isClosed()) {
                conSQLite.close();
                System.out.println("Connection to SQLite closed.");
            }
        } catch (Exception e) {
            System.out.println("Problem with close connection of SQLite");
        }
        //____________________________________________________________________
         try {
            if (!conSQLite2.isClosed()) {
                conSQLite2.close();
                System.out.println("Connection to SQLite2 closed.");
            }
        } catch (Exception e) {
            System.out.println("Problem with close connection of SQLite2");
        }

    }
    
    

}

