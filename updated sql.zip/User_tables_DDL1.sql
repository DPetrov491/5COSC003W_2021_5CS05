/*
**	5COSC003W.2 Software Development Group Project
*	Coursework 2
*	
*	Omar Ahmed
*	
*	User Database objects DDL script
*
*	25/03/2021
*
*/

-- SQLite Group 5CS05 v0.1


/*
Drop existing tables
*/
DROP TABLE Users_Activity;
DROP TABLE Users;

/*
Create Users table
*/
CREATE TABLE Users
(
userId		INT(4)        NOT NULL,
userName 		VARCHAR2(30)  NOT NULL,
fname		VARCHAR2(15),
lname		VARCHAR2(15),
email		VARCHAR2(30)    NOT NULL,
password		VARCHAR2(20)    NOT NULL,
regDateTime		DateTime	    NOT NULL, -- ('%Y-%m-%d %H:%M:%S', ...)
CONSTRAINT c_uid_pk PRIMARY KEY (userId)
);

/*
Create Users_Activity table
*/
CREATE TABLE Users_Activity
(
activityId	INT(4)	NOT NULL,
login	INT(6) 	NOT NULL,
logOut	INT(6)	NOT NULL,
userId	INT(4)	NOT NULL,
CONSTRAINT c_aid_pk PRIMARY KEY (activityId),
CONSTRAINT c_uid_fk FOREIGN KEY (userId) REFERENCES Users (userId)
);

select * from Users;
select * from Users_Activity;